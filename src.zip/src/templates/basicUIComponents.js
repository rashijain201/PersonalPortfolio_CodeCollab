export { default as SectionHeading } from "./sectionHeading";
export { default as SubHeading } from "./subHeading";
export { default as CustomButton } from "./customButton";
export { default as GridLayout } from "./gridLayout";
export { default as LargerSectionHeading } from "./largerSectionHeading";
export { default as ProjectComponent } from "./projectComponent";
