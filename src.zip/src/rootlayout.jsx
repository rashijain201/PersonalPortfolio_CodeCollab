import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import Meta from "./components/Meta";
import Chatbot from "./components/Chatbot";
import ParticlesBackground from "./components/ParticlesBackground";
import Home from "./pages/home";
import Experience from "./pages/experience";
import Projects from "./pages/projects";
import TechStack from "./pages/techStack";
import Contact from "./pages/contact";

export default function RootLayout() {
    return (
        <div className="flex flex-col min-h-screen">
            <Meta />
            <Navbar />
            <main className="flex-grow flex">
            <ParticlesBackground />
                <div className="flex flex-col w-full max-w-6xl mx-auto px-4 py-8 relative z-10 scroll-smooth">
                    <div className="min-h-screen scroll-mt-20" id="home">
                        <Home />
                    </div>
                    <div className="min-h-screen scroll-mt-20" id="experience">
                        <Experience />
                    </div>
                    <div className="min-h-screen scroll-mt-20" id="projects">
                        <Projects />
                    </div>
                    <div className="min-h-screen scroll-mt-20" id="TechStack">
                        <TechStack />
                    </div>
                    <div className="min-h-screen scroll-mt-20" id="contact">
                        <Contact />
                    </div>
                    <Chatbot />
                </div>
            </main>
            <Footer />
        </div>
    );
}
